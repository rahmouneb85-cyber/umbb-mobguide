package com.umbb.mobguide;

public class Faculty {

    private String name;
    private String description;
    private String phone;
    private String email;
    private String location;

    public Faculty(String name, String description,
                   String phone, String email, String location) {
        this.name = name;
        this.description = description;
        this.phone = phone;
        this.email = email;
        this.location = location;
    }

    public String getName()        { return name; }
    public String getDescription() { return description; }
    public String getPhone()       { return phone; }
    public String getEmail()       { return email; }
    public String getLocation()    { return location; }
}