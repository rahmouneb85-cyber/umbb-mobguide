package com.umbb.mobguide;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Locale;

public class DepartmentListActivity extends AppCompatActivity {

    ListView listView;
    EditText etSearch;
    TextView tvFacultyHeader;
    ArrayList<Department> departmentList;
    ArrayList<String> departmentNames;
    ArrayAdapter<String> adapter;
    String facultyName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Apply saved language
        applyLanguage();

        setContentView(R.layout.activity_department_list);

        listView = findViewById(R.id.listViewDepartments);
        etSearch = findViewById(R.id.etSearch);
        tvFacultyHeader = findViewById(R.id.tvFacultyHeader);

        facultyName = getIntent().getStringExtra("faculty_name");
        if (facultyName == null) {
            facultyName = "";
        }
        tvFacultyHeader.setText(facultyName);

        loadDepartments();

        // Click on department
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                String clickedName = adapter.getItem(position);
                Department selected = null;
                for (Department d : departmentList) {
                    if (d.getName().equals(clickedName)) {
                        selected = d;
                        break;
                    }
                }
                if (selected != null) {
                    Intent intent = new Intent(DepartmentListActivity.this,
                            DepartmentDetailActivity.class);
                    intent.putExtra("dept_name", selected.getName());
                    intent.putExtra("dept_desc", selected.getDescription());
                    intent.putExtra("dept_spec", selected.getSpecialties());
                    intent.putExtra("dept_phone", selected.getPhone());
                    intent.putExtra("dept_email", selected.getEmail());
                    intent.putExtra("dept_location", selected.getLocation());
                    startActivity(intent);
                }
            }
        });

        // Search
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                adapter.getFilter().filter(s);
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void applyLanguage() {
        String lang = MainActivity.getSavedLanguage(this);
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        getResources().updateConfiguration(config,
                getResources().getDisplayMetrics());
    }

    private void loadDepartments() {
        departmentList = DataProvider.getDepartments(facultyName);
        departmentNames = new ArrayList<>();
        for (Department d : departmentList) {
            departmentNames.add(d.getName());
        }

        adapter = new ArrayAdapter<>(this,
                R.layout.list_item_department,
                R.id.tvDepartmentName,
                departmentNames);
        listView.setAdapter(adapter);
    }
}