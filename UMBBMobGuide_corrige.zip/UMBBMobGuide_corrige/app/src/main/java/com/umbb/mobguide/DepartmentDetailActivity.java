package com.umbb.mobguide;

import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class DepartmentDetailActivity extends AppCompatActivity {

    TextView tvDeptName, tvDescription, tvSpecialties;
    Button btnCall, btnSms, btnEmail, btnMap;
    String phone, email, location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Apply saved language
        applyLanguage();

        setContentView(R.layout.activity_department_detail);

        // Find views
        tvDeptName     = findViewById(R.id.tvDeptName);
        tvDescription  = findViewById(R.id.tvDescription);
        tvSpecialties  = findViewById(R.id.tvSpecialties);
        btnCall        = findViewById(R.id.btnCall);
        btnSms         = findViewById(R.id.btnSms);
        btnEmail       = findViewById(R.id.btnEmail);
        btnMap         = findViewById(R.id.btnMap);

        // Get data from intent
        String name = getIntent().getStringExtra("dept_name");
        String desc = getIntent().getStringExtra("dept_desc");
        String spec = getIntent().getStringExtra("dept_spec");
        phone        = getIntent().getStringExtra("dept_phone");
        email        = getIntent().getStringExtra("dept_email");
        location     = getIntent().getStringExtra("dept_location");

        // Set data
        tvDeptName.setText(name);
        tvDescription.setText(desc);
        tvSpecialties.setText(spec);

        // Call button
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + phone));
                startActivity(intent);
            }
        });

        // SMS button
        btnSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("smsto:" + phone));
                startActivity(intent);
            }
        });

        // Email button
        btnEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:" + email));
                startActivity(intent);
            }
        });

        // Map button
        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("geo:" + location +
                        "?q=" + location));
                startActivity(intent);
            }
        });
    }

    private void applyLanguage() {
        String lang = MainActivity.getSavedLanguage(this);
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        getResources().updateConfiguration(config,
                getResources().getDisplayMetrics());
    }
}