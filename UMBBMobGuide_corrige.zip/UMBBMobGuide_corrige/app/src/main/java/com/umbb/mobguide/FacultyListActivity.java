package com.umbb.mobguide;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Locale;

public class FacultyListActivity extends AppCompatActivity {

    ListView listView;
    EditText etSearch;
    ArrayList<Faculty> facultyList;
    ArrayList<String> facultyNames;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Apply saved language
        applyLanguage();

        setContentView(R.layout.activity_faculty_list);

        listView = findViewById(R.id.listViewFaculties);
        etSearch = findViewById(R.id.etSearch);

        loadFaculties();

        // Click on faculty
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                String selectedName = adapter.getItem(position);
                Faculty selected = null;
                for (Faculty f : facultyList) {
                    if (f.getName().equals(selectedName)) {
                        selected = f;
                        break;
                    }
                }
                if (selected != null) {
                    Intent intent = new Intent(FacultyListActivity.this,
                            DepartmentListActivity.class);
                    intent.putExtra("faculty_name", selected.getName());
                    startActivity(intent);
                }
            }
        });

        // Search
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                adapter.getFilter().filter(s);
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    private void applyLanguage() {
        String lang = MainActivity.getSavedLanguage(this);
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        getResources().updateConfiguration(config,
                getResources().getDisplayMetrics());
    }

    private void loadFaculties() {
        facultyList = DataProvider.getFaculties(this);
        facultyNames = new ArrayList<>();
        for (Faculty f : facultyList) {
            facultyNames.add(f.getName());
        }

        adapter = new ArrayAdapter<>(this,
                R.layout.list_item_faculty,
                R.id.tvFacultyName,
                facultyNames);
        listView.setAdapter(adapter);
    }
}