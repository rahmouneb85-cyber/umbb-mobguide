package com.umbb.mobguide;

import android.content.Context;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

public class DataProvider {

    // Check if current language is Arabic
    private static boolean isArabic() {
        return Locale.getDefault().getLanguage().equals("ar");
    }

    public static ArrayList<Faculty> getFaculties(Context context) {
        ArrayList<Faculty> list = new ArrayList<>();

        if (isArabic()) {
            list.add(new Faculty("كلية العلوم",
                    "تضم أقسام العلوم الأساسية والتطبيقية: الإعلام الآلي، الرياضيات، الفيزياء، الكيمياء، البيولوجيا والزراعة.",
                    "+213 24 91 14 30", "fs@univ-boumerdes.dz", "36.762846,3.476025"));
            list.add(new Faculty("كلية المحروقات والكيمياء",
                    "متخصصة في مجالات البترول والغاز والكيمياء وعلوم الأرض.",
                    "+213 24 91 14 31", "fhc@univ-boumerdes.dz", "36.763262,3.472810"));
            list.add(new Faculty("كلية التكنولوجيا",
                    "تكوين مهندسين في الهندسة المدنية والميكانيكية والكهربائية.",
                    "+213 24 91 14 32", "ft@univ-boumerdes.dz", "36.761310,3.457731"));
            list.add(new Faculty("معهد الهندسة الكهربائية والإلكترونية",
                    "يقدم تكوينات في الإلكترونيك والأتمتة والكهروتقنية.",
                    "+213 24 91 14 33", "igee@univ-boumerdes.dz", "36.758849,3.472691"));
            list.add(new Faculty("كلية الحقوق والعلوم السياسية",
                    "تدريس القانون العام والخاص والعلوم السياسية.",
                    "+213 24 91 14 34", "fdsp@univ-boumerdes.dz", "36.731838,3.392180"));
            list.add(new Faculty("كلية الآداب واللغات",
                    "تكوين الطلاب في اللغة العربية والفرنسية والإنجليزية.",
                    "+213 24 91 14 35", "fll@univ-boumerdes.dz", "36.757937,3.471659"));
            list.add(new Faculty("كلية العلوم الاقتصادية",
                    "تغطي علوم التسيير والاقتصاد والمالية والمحاسبة والعلوم التجارية.",
                    "+213 24 91 14 36", "fseg@univ-boumerdes.dz", "36.763685,3.475822"));
            list.add(new Faculty("معهد العلوم والتقنيات التطبيقية",
                    "متخصص في القياس والمترولوجيا والجودة الصناعية.",
                    "+213 24 91 14 37", "ista@univ-boumerdes.dz", "36.762664,3.476958"));
        } else {
            list.add(new Faculty("Faculté des Sciences",
                    "La Faculté des Sciences regroupe les départements de sciences fondamentales et appliquées : informatique, mathématiques, physique, chimie, biologie et agronomie.",
                    "+213 24 91 14 30", "fs@univ-boumerdes.dz", "36.762846,3.476025"));
            list.add(new Faculty("Faculté des Hydrocarbures et de la Chimie",
                    "Spécialisée dans les domaines du pétrole, du gaz, de la chimie et des géosciences.",
                    "+213 24 91 14 31", "fhc@univ-boumerdes.dz", "36.763262,3.472810"));
            list.add(new Faculty("Faculté de Technologie",
                    "La Faculté de Technologie forme des ingénieurs dans les domaines du génie civil, mécanique, électrique et des procédés industriels.",
                    "+213 24 91 14 32", "ft@univ-boumerdes.dz", "36.761310,3.457731"));
            list.add(new Faculty("Institut de Génie Électrique et Électronique",
                    "L'IGEE propose des formations en électronique, automatique et électrotechnique.",
                    "+213 24 91 14 33", "igee@univ-boumerdes.dz", "36.758849,3.472691"));
            list.add(new Faculty("Faculté de Droit et Sciences Politiques",
                    "Cette faculté dispense des enseignements en droit public, droit privé et sciences politiques.",
                    "+213 24 91 14 34", "fdsp@univ-boumerdes.dz", "36.731838,3.392180"));
            list.add(new Faculty("Faculté des Lettres et des Langues",
                    "La Faculté des Lettres et des Langues forme des étudiants en langue arabe, française et anglaise.",
                    "+213 24 91 14 35", "fll@univ-boumerdes.dz", "36.757937,3.471659"));
            list.add(new Faculty("Faculté des Sciences Économiques",
                    "Cette faculté couvre les sciences de gestion, économiques, finance, comptabilité et sciences commerciales.",
                    "+213 24 91 14 36", "fseg@univ-boumerdes.dz", "36.763685,3.475822"));
            list.add(new Faculty("Institut des Sciences et Techniques Appliquées",
                    "L'ISTA est spécialisé dans les domaines de la mesure, métrologie et qualité industrielle.",
                    "+213 24 91 14 37", "ista@univ-boumerdes.dz", "36.762664,3.476958"));
        }

        return list;
    }

    public static ArrayList<Department> getDepartments(String facultyName) {
        HashMap<String, ArrayList<Department>> map = new HashMap<>();

        // === FRENCH DEPARTMENTS ===
        ArrayList<Department> sciences = new ArrayList<>();
        sciences.add(new Department("Département Informatique",
                "Formation en génie logiciel, réseaux, intelligence artificielle et systèmes d'information.",
                "L3 SI, L3 ISIL, Master Réseaux, Master IA",
                "+213 24 91 14 40", "info@fs.univ-boumerdes.dz", "36.751699,3.470212"));
        sciences.add(new Department("Département Mathématiques",
                "Algèbre, analyse, probabilités et mathématiques appliquées.",
                "L3 Mathématiques, Master Maths Appliquées",
                "+213 24 91 14 41", "math@fs.univ-boumerdes.dz", "36.762846,3.476025"));
        sciences.add(new Department("Département Physique",
                "Physique classique et moderne, optique et physique des matériaux.",
                "L3 Physique, Master Matériaux",
                "+213 24 91 14 42", "physique@fs.univ-boumerdes.dz", "36.750730,3.467743"));
        sciences.add(new Department("Département Chimie",
                "Chimie organique, inorganique et chimie analytique.",
                "L3 Chimie, Master Chimie Analytique",
                "+213 24 91 14 43", "chimie@fs.univ-boumerdes.dz", "36.762846,3.476025"));
        sciences.add(new Department("Département Biologie",
                "Biologie cellulaire, microbiologie, biochimie et écologie.",
                "L3 Biologie, Master Microbiologie",
                "+213 24 91 14 44", "bio@fs.univ-boumerdes.dz", "36.762846,3.476025"));
        sciences.add(new Department("Département Agronomie",
                "Agronomie, sciences du sol, production végétale et animale.",
                "L3 Agronomie, Master Agronomie",
                "+213 24 91 14 45", "agro@fs.univ-boumerdes.dz", "36.762846,3.476025"));
        sciences.add(new Department("Département STAPS",
                "Sciences et Techniques des Activités Physiques et Sportives.",
                "L3 STAPS, Master Entraînement Sportif",
                "+213 24 91 14 46", "staps@fs.univ-boumerdes.dz", "36.762846,3.476025"));
        map.put("Faculté des Sciences", sciences);

        ArrayList<Department> hydro = new ArrayList<>();
        hydro.add(new Department("Département Automatisation des Procédés",
                "Automatisation industrielle et électrification des procédés pétroliers.",
                "L3 Automatique, Master Automatisation",
                "+213 24 91 14 50", "auto@fhc.univ-boumerdes.dz", "36.763262,3.472810"));
        hydro.add(new Department("Département Gisements Miniers et Pétroliers",
                "Exploration et exploitation des gisements pétroliers et miniers.",
                "L3 Géologie, Master Pétrole",
                "+213 24 91 14 51", "gmp@fhc.univ-boumerdes.dz", "36.763262,3.472810"));
        hydro.add(new Department("Département Génie des Procédés Chimiques",
                "Traitement chimique et pharmaceutique des hydrocarbures.",
                "L3 Génie Chimique, Master Procédés",
                "+213 24 91 14 52", "gpc@fhc.univ-boumerdes.dz", "36.763262,3.472810"));
        hydro.add(new Department("Département Transport des Hydrocarbures",
                "Transport et équipements liés aux hydrocarbures.",
                "L3 Transport HC, Master Pipeline",
                "+213 24 91 14 53", "thc@fhc.univ-boumerdes.dz", "36.763262,3.472810"));
        map.put("Faculté des Hydrocarbures et de la Chimie", hydro);

        ArrayList<Department> tech = new ArrayList<>();
        tech.add(new Department("Département Génie Civil",
                "Construction, structures, géotechnique et urbanisme.",
                "L3 Génie Civil, Master Structures",
                "+213 24 91 14 60", "gc@ft.univ-boumerdes.dz", "36.761310,3.457731"));
        tech.add(new Department("Département Génie Mécanique",
                "Thermodynamique, mécanique des fluides et conception industrielle.",
                "L3 Mécanique, Master Thermique",
                "+213 24 91 14 61", "gm@ft.univ-boumerdes.dz", "36.761310,3.457731"));
        tech.add(new Department("Département Génie des Procédés",
                "Procédés industriels, génie chimique et environnemental.",
                "L3 Procédés, Master Environnement",
                "+213 24 91 14 62", "gp@ft.univ-boumerdes.dz", "36.761310,3.457731"));
        tech.add(new Department("Département Génie Electrique",
                "Alimentation électrique, machines et systèmes électriques industriels.",
                "L3 Génie Électrique, Master Énergie",
                "+213 24 91 14 63", "ge@ft.univ-boumerdes.dz", "36.761310,3.457731"));
        map.put("Faculté de Technologie", tech);

        ArrayList<Department> igee = new ArrayList<>();
        igee.add(new Department("Département Électronique",
                "Électronique numérique, télécommunications et traitement du signal.",
                "L3 Électronique, Master Télécoms",
                "+213 24 91 14 70", "elec@igee.univ-boumerdes.dz", "36.758849,3.472691"));
        igee.add(new Department("Département Automatique et Électrotechnique",
                "Automatique industrielle, électrotechnique et systèmes de contrôle.",
                "L3 Électrotechnique, Master Automatique",
                "+213 24 91 14 71", "auto@igee.univ-boumerdes.dz", "36.758849,3.472691"));
        igee.add(new Department("Département Enseignements de Base",
                "Tronc commun L1/L2/L3 pour les étudiants de l'IGEE.",
                "L1, L2, L3 Tronc commun",
                "+213 24 91 14 72", "base@igee.univ-boumerdes.dz", "36.758849,3.472691"));
        map.put("Institut de Génie Électrique et Électronique", igee);

        ArrayList<Department> droit = new ArrayList<>();
        droit.add(new Department("Département Droit Public",
                "Droit constitutionnel, administratif et droit international public.",
                "L3 Droit Public, Master Droit Admin",
                "+213 24 91 14 80", "dpub@fdsp.univ-boumerdes.dz", "36.731838,3.392180"));
        droit.add(new Department("Département Droit Privé",
                "Droit civil, droit des affaires et droit de la famille.",
                "L3 Droit Privé, Master Droit des Affaires",
                "+213 24 91 14 81", "dpriv@fdsp.univ-boumerdes.dz", "36.731838,3.392180"));
        droit.add(new Department("Département Sciences Politiques",
                "Relations internationales, gouvernance et sciences politiques.",
                "L3 Sciences Po, Master Relations Internationales",
                "+213 24 91 14 82", "sp@fdsp.univ-boumerdes.dz", "36.731838,3.392180"));
        map.put("Faculté de Droit et Sciences Politiques", droit);

        ArrayList<Department> lettres = new ArrayList<>();
        lettres.add(new Department("Département Lettres Arabes",
                "Langue et littérature arabes, linguistique arabe classique et moderne.",
                "L3 Lettres Arabes, Master Linguistique",
                "+213 24 91 14 90", "arabe@fll.univ-boumerdes.dz", "36.757937,3.471659"));
        lettres.add(new Department("Département Anglais",
                "Langue anglaise, littérature anglophone et traduction.",
                "L3 Anglais, Master Traduction",
                "+213 24 91 14 91", "anglais@fll.univ-boumerdes.dz", "36.757937,3.471659"));
        lettres.add(new Department("Département Français",
                "Langue française, littérature francophone et didactique du FLE.",
                "L3 Français, Master FLE",
                "+213 24 91 14 92", "francais@fll.univ-boumerdes.dz", "36.757937,3.471659"));
        map.put("Faculté des Lettres et des Langues", lettres);

        ArrayList<Department> eco = new ArrayList<>();
        eco.add(new Department("Département Sciences Économiques",
                "Microéconomie, macroéconomie et politique économique.",
                "L3 Économie, Master Économie du Développement",
                "+213 24 91 15 00", "eco@fseg.univ-boumerdes.dz", "36.763685,3.475822"));
        eco.add(new Department("Département Sciences de Gestion",
                "Management, ressources humaines et stratégie d'entreprise.",
                "L3 Gestion, Master Management",
                "+213 24 91 15 01", "gestion@fseg.univ-boumerdes.dz", "36.763685,3.475822"));
        eco.add(new Department("Département Finance et Comptabilité",
                "Comptabilité générale, finance d'entreprise et audit.",
                "L3 Finance, Master Audit et Contrôle",
                "+213 24 91 15 02", "finance@fseg.univ-boumerdes.dz", "36.763685,3.475822"));
        eco.add(new Department("Département Sciences Commerciales",
                "Marketing, commerce international et management commercial.",
                "L3 Commerce, Master Marketing",
                "+213 24 91 15 03", "commerce@fseg.univ-boumerdes.dz", "36.763685,3.475822"));
        map.put("Faculté des Sciences Économiques", eco);

        ArrayList<Department> ista = new ArrayList<>();
        ista.add(new Department("Département Mesure, Métrologie et Qualité",
                "Métrologie industrielle, contrôle qualité et instruments de mesure.",
                "L3 Métrologie, Master Qualité Industrielle",
                "+213 24 91 15 10", "mmq@ista.univ-boumerdes.dz", "36.762664,3.476958"));
        map.put("Institut des Sciences et Techniques Appliquées", ista);

        // === ARABIC DEPARTMENTS ===
        ArrayList<Department> sciences_ar = new ArrayList<>();
        sciences_ar.add(new Department("قسم الإعلام الآلي",
                "تكوين في هندسة البرمجيات والشبكات والذكاء الاصطناعي وأنظمة المعلومات.",
                "ل3 ن م، ل3 إ ن م، ماستر شبكات، ماستر ذكاء اصطناعي",
                "+213 24 91 14 40", "info@fs.univ-boumerdes.dz", "36.751699,3.470212"));
        sciences_ar.add(new Department("قسم الرياضيات",
                "الجبر والتحليل والاحتمالات والرياضيات التطبيقية.",
                "ل3 رياضيات، ماستر رياضيات تطبيقية",
                "+213 24 91 14 41", "math@fs.univ-boumerdes.dz", "36.762846,3.476025"));
        sciences_ar.add(new Department("قسم الفيزياء",
                "الفيزياء الكلاسيكية والحديثة والبصريات وفيزياء المواد.",
                "ل3 فيزياء، ماستر مواد",
                "+213 24 91 14 42", "physique@fs.univ-boumerdes.dz", "36.750730,3.467743"));
        sciences_ar.add(new Department("قسم الكيمياء",
                "الكيمياء العضوية وغير العضوية والكيمياء التحليلية.",
                "ل3 كيمياء، ماستر كيمياء تحليلية",
                "+213 24 91 14 43", "chimie@fs.univ-boumerdes.dz", "36.762846,3.476025"));
        sciences_ar.add(new Department("قسم البيولوجيا",
                "بيولوجيا الخلية والميكروبيولوجيا والكيمياء الحيوية والبيئة.",
                "ل3 بيولوجيا، ماستر ميكروبيولوجيا",
                "+213 24 91 14 44", "bio@fs.univ-boumerdes.dz", "36.762846,3.476025"));
        sciences_ar.add(new Department("قسم الزراعة",
                "الزراعة وعلوم التربة والإنتاج النباتي والحيواني.",
                "ل3 زراعة، ماستر زراعة",
                "+213 24 91 14 45", "agro@fs.univ-boumerdes.dz", "36.762846,3.476025"));
        sciences_ar.add(new Department("قسم STAPS",
                "علوم وتقنيات الأنشطة البدنية والرياضية.",
                "ل3 STAPS، ماستر تدريب رياضي",
                "+213 24 91 14 46", "staps@fs.univ-boumerdes.dz", "36.762846,3.476025"));
        map.put("كلية العلوم", sciences_ar);

        ArrayList<Department> hydro_ar = new ArrayList<>();
        hydro_ar.add(new Department("قسم أتمتة العمليات",
                "الأتمتة الصناعية وكهربة العمليات البترولية.",
                "ل3 أتمتة، ماستر أتمتة",
                "+213 24 91 14 50", "auto@fhc.univ-boumerdes.dz", "36.763262,3.472810"));
        hydro_ar.add(new Department("قسم المناجم والمحاجر البترولية",
                "استكشاف واستغلال الرواسب البترولية والمنجمية.",
                "ل3 جيولوجيا، ماستر بترول",
                "+213 24 91 14 51", "gmp@fhc.univ-boumerdes.dz", "36.763262,3.472810"));
        hydro_ar.add(new Department("قسم هندسة العمليات الكيميائية",
                "المعالجة الكيميائية والصيدلانية للمحروقات.",
                "ل3 هندسة كيميائية، ماستر عمليات",
                "+213 24 91 14 52", "gpc@fhc.univ-boumerdes.dz", "36.763262,3.472810"));
        hydro_ar.add(new Department("قسم نقل المحروقات",
                "نقل وتجهيزات المحروقات.",
                "ل3 نقل المحروقات، ماستر أنابيب",
                "+213 24 91 14 53", "thc@fhc.univ-boumerdes.dz", "36.763262,3.472810"));
        map.put("كلية المحروقات والكيمياء", hydro_ar);

        ArrayList<Department> tech_ar = new ArrayList<>();
        tech_ar.add(new Department("قسم الهندسة المدنية",
                "البناء والهياكل والجيوتقنية والتعمير.",
                "ل3 هندسة مدنية، ماستر هياكل",
                "+213 24 91 14 60", "gc@ft.univ-boumerdes.dz", "36.761310,3.457731"));
        tech_ar.add(new Department("قسم الهندسة الميكانيكية",
                "الديناميكا الحرارية وميكانيكا الموائع والتصميم الصناعي.",
                "ل3 ميكانيك، ماستر حراري",
                "+213 24 91 14 61", "gm@ft.univ-boumerdes.dz", "36.761310,3.457731"));
        tech_ar.add(new Department("قسم هندسة العمليات",
                "العمليات الصناعية والهندسة الكيميائية والبيئية.",
                "ل3 عمليات، ماستر بيئة",
                "+213 24 91 14 62", "gp@ft.univ-boumerdes.dz", "36.761310,3.457731"));
        tech_ar.add(new Department("قسم الهندسة الكهربائية",
                "التغذية الكهربائية والآلات والأنظمة الكهربائية الصناعية.",
                "ل3 هندسة كهربائية، ماستر طاقة",
                "+213 24 91 14 63", "ge@ft.univ-boumerdes.dz", "36.761310,3.457731"));
        map.put("كلية التكنولوجيا", tech_ar);

        ArrayList<Department> igee_ar = new ArrayList<>();
        igee_ar.add(new Department("قسم الإلكترونيك",
                "الإلكترونيك الرقمي والاتصالات ومعالجة الإشارة.",
                "ل3 إلكترونيك، ماستر اتصالات",
                "+213 24 91 14 70", "elec@igee.univ-boumerdes.dz", "36.758849,3.472691"));
        igee_ar.add(new Department("قسم الأتمتة والكهروتقنية",
                "الأتمتة الصناعية والكهروتقنية وأنظمة التحكم.",
                "ل3 كهروتقنية، ماستر أتمتة",
                "+213 24 91 14 71", "auto@igee.univ-boumerdes.dz", "36.758849,3.472691"));
        igee_ar.add(new Department("قسم التعليم الأساسي",
                "جذع مشترك ل1/ل2/ل3 لطلاب المعهد.",
                "ل1، ل2، ل3 جذع مشترك",
                "+213 24 91 14 72", "base@igee.univ-boumerdes.dz", "36.758849,3.472691"));
        map.put("معهد الهندسة الكهربائية والإلكترونية", igee_ar);

        ArrayList<Department> droit_ar = new ArrayList<>();
        droit_ar.add(new Department("قسم القانون العام",
                "القانون الدستوري والإداري والقانون الدولي العام.",
                "ل3 قانون عام، ماستر قانون إداري",
                "+213 24 91 14 80", "dpub@fdsp.univ-boumerdes.dz", "36.731838,3.392180"));
        droit_ar.add(new Department("قسم القانون الخاص",
                "القانون المدني وقانون الأعمال وقانون الأسرة.",
                "ل3 قانون خاص، ماستر قانون الأعمال",
                "+213 24 91 14 81", "dpriv@fdsp.univ-boumerdes.dz", "36.731838,3.392180"));
        droit_ar.add(new Department("قسم العلوم السياسية",
                "العلاقات الدولية والحوكمة والعلوم السياسية.",
                "ل3 علوم سياسية، ماستر علاقات دولية",
                "+213 24 91 14 82", "sp@fdsp.univ-boumerdes.dz", "36.731838,3.392180"));
        map.put("كلية الحقوق والعلوم السياسية", droit_ar);

        ArrayList<Department> lettres_ar = new ArrayList<>();
        lettres_ar.add(new Department("قسم الآداب العربية",
                "اللغة والأدب العربيين، اللسانيات العربية الكلاسيكية والحديثة.",
                "ل3 آداب عربية، ماستر لسانيات",
                "+213 24 91 14 90", "arabe@fll.univ-boumerdes.dz", "36.757937,3.471659"));
        lettres_ar.add(new Department("قسم اللغة الإنجليزية",
                "اللغة الإنجليزية والأدب الأنجلوفوني والترجمة.",
                "ل3 إنجليزية، ماستر ترجمة",
                "+213 24 91 14 91", "anglais@fll.univ-boumerdes.dz", "36.757937,3.471659"));
        lettres_ar.add(new Department("قسم اللغة الفرنسية",
                "اللغة الفرنسية والأدب الفرانكوفوني وتعليم الفرنسية.",
                "ل3 فرنسية، ماستر FLE",
                "+213 24 91 14 92", "francais@fll.univ-boumerdes.dz", "36.757937,3.471659"));
        map.put("كلية الآداب واللغات", lettres_ar);

        ArrayList<Department> eco_ar = new ArrayList<>();
        eco_ar.add(new Department("قسم العلوم الاقتصادية",
                "الاقتصاد الجزئي والكلي والسياسة الاقتصادية.",
                "ل3 اقتصاد، ماستر اقتصاد التنمية",
                "+213 24 91 15 00", "eco@fseg.univ-boumerdes.dz", "36.763685,3.475822"));
        eco_ar.add(new Department("قسم علوم التسيير",
                "الإدارة والموارد البشرية واستراتيجية المؤسسة.",
                "ل3 تسيير، ماستر إدارة",
                "+213 24 91 15 01", "gestion@fseg.univ-boumerdes.dz", "36.763685,3.475822"));
        eco_ar.add(new Department("قسم المالية والمحاسبة",
                "المحاسبة العامة ومالية المؤسسة والتدقيق.",
                "ل3 مالية، ماستر تدقيق ومراقبة",
                "+213 24 91 15 02", "finance@fseg.univ-boumerdes.dz", "36.763685,3.475822"));
        eco_ar.add(new Department("قسم العلوم التجارية",
                "التسويق والتجارة الدولية والإدارة التجارية.",
                "ل3 تجارة، ماستر تسويق",
                "+213 24 91 15 03", "commerce@fseg.univ-boumerdes.dz", "36.763685,3.475822"));
        map.put("كلية العلوم الاقتصادية", eco_ar);

        ArrayList<Department> ista_ar = new ArrayList<>();
        ista_ar.add(new Department("قسم القياس والمترولوجيا والجودة",
                "المترولوجيا الصناعية ومراقبة الجودة وأجهزة القياس.",
                "ل3 مترولوجيا، ماستر جودة صناعية",
                "+213 24 91 15 10", "mmq@ista.univ-boumerdes.dz", "36.762664,3.476958"));
        map.put("معهد العلوم والتقنيات التطبيقية", ista_ar);

        ArrayList<Department> result = map.get(facultyName);
        return result != null ? result : new ArrayList<>();
    }
}