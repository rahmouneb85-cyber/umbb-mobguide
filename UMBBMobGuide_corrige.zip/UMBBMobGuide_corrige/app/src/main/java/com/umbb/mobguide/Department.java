package com.umbb.mobguide;

public class Department {

    private String name;
    private String description;
    private String specialties;
    private String phone;
    private String email;
    private String location;

    public Department(String name, String description,
                      String specialties, String phone,
                      String email, String location) {
        this.name = name;
        this.description = description;
        this.specialties = specialties;
        this.phone = phone;
        this.email = email;
        this.location = location;
    }

    public String getName()        { return name; }
    public String getDescription() { return description; }
    public String getSpecialties() { return specialties; }
    public String getPhone()       { return phone; }
    public String getEmail()       { return email; }
    public String getLocation()    { return location; }
}