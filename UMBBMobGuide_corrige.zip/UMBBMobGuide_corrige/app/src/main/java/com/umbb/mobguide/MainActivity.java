package com.umbb.mobguide;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    Button btnExploreFaculties, btnLanguage;

    // We save the language in SharedPreferences
    // so it stays even after restart
    public static final String PREF_NAME = "settings";
    public static final String PREF_LANG = "language";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Apply saved language BEFORE setContentView
        applySavedLanguage();

        setContentView(R.layout.activity_main);

        btnExploreFaculties = findViewById(R.id.btnExploreFaculties);
        btnLanguage = findViewById(R.id.btnLanguage);

        // Update button text based on current language
        updateLanguageButton();

        // Go to Faculty List
        btnExploreFaculties.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,
                        FacultyListActivity.class);
                startActivity(intent);
            }
        });

        // Toggle language
        btnLanguage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String current = getSavedLanguage();
                if (current.equals("ar")) {
                    saveLanguage("en");
                } else {
                    saveLanguage("ar");
                }
                // Restart app to apply
                restartApp();
            }
        });
    }

    // Apply language from saved preferences
    private void applySavedLanguage() {
        String lang = getSavedLanguage();
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        getResources().updateConfiguration(config,
                getResources().getDisplayMetrics());
    }

    // Update button text: show opposite language
    private void updateLanguageButton() {
        String current = getSavedLanguage();
        if (current.equals("ar")) {
            btnLanguage.setText("English");
        } else {
            btnLanguage.setText("عربي");
        }
    }

    // Save language to SharedPreferences
    private void saveLanguage(String lang) {
        SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        prefs.edit().putString(PREF_LANG, lang).apply();
    }

    // Get saved language (default = English)
    public static String getSavedLanguage(android.content.Context context) {
        SharedPreferences prefs = context.getSharedPreferences(
                PREF_NAME, MODE_PRIVATE);
        return prefs.getString(PREF_LANG, "en");
    }

    private String getSavedLanguage() {
        return getSavedLanguage(this);
    }

    // Fully restart the app
    private void restartApp() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_CLEAR_TASK);
        finish();
        startActivity(intent);
    }
}